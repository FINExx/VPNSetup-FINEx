<div class="main-wrapper">
    <div class="account-page">
        <div class="container">
            <h3 class="account-title"><img src="../asset/noypi/img/noypissh.png"></h3>
            <div class="account-box">
                <div class="account-wrapper">
	                <?php if ($message): ?>
	                    <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
	                <?php endif; ?>
                    <form action="/login" method="post">
                        <div class="form-group form-focus">
                            <label class="control-label">Username</label>
                            <input class="form-control floating" type="text" required="required" id="username" name="username" value="" placeholder="Username">
                        </div>
                        <div class="form-group form-focus">
                            <label class="control-label">Password</label>
                            <input class="form-control floating" required="required" id="password" type="password" name="password" placeholder="Password">
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-default btn-noypi btn-block account-btn" mame="submit" type="submit"><font color="white">Login</font></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>