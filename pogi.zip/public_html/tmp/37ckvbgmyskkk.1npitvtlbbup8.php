    <div class="main-wrapper" id="singpo"> 
     <div class="header">


<nav class="navbar navbar-default">
  <div class="container-fluid" style="background: #6c6c75;">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      
      	<a id="mobile_btn" style="padding-left: 10%;color:black;" class="mobile_btn pull-left" href="#sidebar"><i class="fa fa-bars" aria-hidden="true"></i></a>
      
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a href="/">
      <img src="/asset/noypi/img/logo.png" width="50">
    	</a>
    	
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left" ">


        <li><a style="color:white;" href="#" onclick="myFunction()">Hide</a></li>

        <li><a style="color:white;" href="#" onclick="myFunction1()">Show</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>



        </div>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">MAIN MENU</li>
                        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                        <?php if ($me->type==1): ?>
                          
                            <li class="submenu">
                                <a href="#"><i class="fa fa-server" aria-hidden="true"></i> <span> Server</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled" style="display: none;">
                                    <li><a href="/home/admin/server"><i class="fa fa-circle-o"></i> List Server</a></li>
                                    <li><a href="/home/admin/server/add"><i class="fa fa-circle-o"></i> Add Server</a></li>
                                </ul>
                            </li>
                            
                        <li><a href="/logout" ><i class=" fa fa-sign-out" ></i><span>Log out</span></a></li>
                        <li></li>
                    </ul>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        	function myFunction(){
        document.getElementById("sidebar").style.left="-20%";
      }
      function myFunction1(){
        document.getElementById("sidebar").style.left="0";
      }
                        	</script>
        <?php echo $this->render($subcontent,$this->mime,get_defined_vars()); ?> <?php endif; ?>