  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
     <?php if ($user->uid): ?>
                    
                          <div class="container">
             <section class="content-header">         
                 <h1> Edit User
                      </h1>
                    
      <ol class="breadcrumb" style="@media only screen and (min-width: 768px) {padding-left: 20%;}>
        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/server">List Server</a></li>
        <li class="active">Edit User</li>
      </ol>
    </section>
     
					
                    <?php else: ?>
                      <section class="content-header">
                      <h1>
                        Add User
						                          </h1>
      <ol class="breadcrumb" style="@media only screen and (min-width: 768px) {padding-left: 20%;}"  >
        <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="/home/admin/server">List Server</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>
                    
            <?php endif; ?>


    <!-- Main content -->
    <section class="content" style="@media only screen and (min-width: 768px) {padding-left: 20%;}"> 
    
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>

		<div class="row">
        <div class="col-md-6">	
			         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title">Account Details </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="user" type="text" value="<?php echo $user->user; ?>" required>
                        </div>
                        <?php if (!$user->uid): ?>
                            <div class="form-group">
                                <label>Password</label>
                      <input class="form-control" placeholder="New Password" name="pass" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                      <input class="form-control" placeholder="Re-enter Password" name="pass_confirmation" type="password" required>
                            </div>
                        <?php endif; ?>
              <div class="form-group">
                <label>Exp</label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="datepicker" name="exp" value="<?php echo $user->exp?$user->exp:date("Y/m/d",strtotime("+30 days")); ?>">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
						
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
                        <?php if ($user->uid): ?>
                            
                                <?php if ($user->lock): ?>
                                    
                                        <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlock</a>
                                    
                                    <?php else: ?>
                                        <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Lock</a>
                                    
                                <?php endif; ?>
                                <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                            
                            <?php else: ?>
                                <a href="/home/admin/server/<?php echo $server->id; ?>/account/" class="btn btn-default">Back</a>
                            
                        <?php endif; ?>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>		  
       
        <?php if ($user->uid): ?>		  
        <div class="col-md-6">		  
         <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">Change Password</h3>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save</button>
     <a href="/home/admin/server/<?php echo $server->id; ?>/account/" class="btn btn-default pull-right"><i class="fa fa-arrow-left"></i> Back</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
<?php endif; ?>
		  
          </div>		
          </div>  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->