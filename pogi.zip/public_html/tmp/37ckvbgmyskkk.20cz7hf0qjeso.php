<div class="page-wrapper" style="min-height: 496px;">
  <div class="content container-fluid">

  <div class="row">
    <div class="col-xs-12">
      <h4 class="page-title">
        <?php if ($server->id): ?>
            
                <?php echo $server->servername; ?>
            
            <?php else: ?>
                Add Server
            
        <?php endif; ?>
      </h4>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12">
      <div class="card-box">
      <?php if ($message): ?>     
          <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo $message['data']; ?>
          </div>
        <?php endif; ?>
        <div class="box box-primary">
          <div class="box-header with-border">
             <h3 class="box-title"> Server Settings</h3>
          </div>
          <form role="form" action="<?php echo $URI; ?>" method="POST" class="form-horizontal">
            <div class="box-body">
              <div class="form-group">
                <label class="control-label col-lg-12">Location</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="Singapore, Malaysia" name="country" type="text" value="<?php echo $server->country; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">ISP</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="Digital Ocean 1, Vultr 1" name="servername" type="text" value="<?php echo $server->servername; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">IP / Hostname</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="128.199.xxx.xx or www.example-server.com" name="host" type="text" value="<?php echo $server->host; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">SSH Port</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="22" name="openssh" type="text" value="<?php echo $server->openssh; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Dropbear Port</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="443" name="dropbear" type="text" value="<?php echo $server->dropbear; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Squid Port</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="8080, 3128" name="info" type="text" value="<?php echo $server->info; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">User Limit</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="50" name="limitacc" type="text" value="<?php echo $server->limitacc; ?>" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Allow Torrent?</label>
                <div class="col-md-12">
                  <select class="form-control" name="badvpn" value="<?php echo $server->badvpn; ?>">
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Price</label>
                <div class="col-md-12">
                  <div class="input-group">
                      <span class="input-group-addon">₱</span>
                      <input class="form-control" placeholder="10" name="price" type="number" step="1" value="<?php echo $server->price; ?>" required>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-lg-12">Root Password</label>
                <div class="col-md-12">
                  <input class="form-control" placeholder="root" name="root_pass" type="password">
                </div>
              </div>
              <div align="right">
                <button type="submit" class="btn btn-primary">Save</button>
                <?php if ($server->id): ?>
                  <?php if ($server->active==1): ?>
                  
                    <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Lock</a>
                  
                  <?php else: ?>
                    <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlock</a>
                  
                  <?php endif; ?>
                  <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                <?php endif; ?>
                <a href="/home/admin/server" class="btn btn-default">Back</a>
              </div>
            </div>
          </form>
        </form>
      </div>
    </div>
  </div>

  </div>
</div>





