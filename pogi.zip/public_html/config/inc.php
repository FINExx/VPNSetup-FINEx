<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="45a00f0ed0423ee7f7b6b64a02463ea990121e2d15a8ef7b3be99a5978f7efc4"
DB_SET="mysql:host=localhost;port=3306;dbname=OCS_PANEL"
DB_USER="root"
DB_PASS="panda29"
?>